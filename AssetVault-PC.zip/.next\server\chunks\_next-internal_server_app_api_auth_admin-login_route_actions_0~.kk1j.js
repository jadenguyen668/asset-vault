module.exports=[3953,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_auth_admin-login_route_actions_0~.kk1j.js.map