var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/delete-character/route.js")
R.c("server/chunks/[root-of-the-server]__0~-cayq._.js")
R.c("server/chunks/_0p.uumx._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_delete-character_route_actions_0zryoec.js")
R.m(79106)
module.exports=R.m(79106).exports
