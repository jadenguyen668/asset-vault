module.exports=[81299,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_convert-spine_route_actions_04a.yh7.js.map