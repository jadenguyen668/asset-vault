var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/update-role/route.js")
R.c("server/chunks/[root-of-the-server]__04dp4co._.js")
R.c("server/chunks/_0p.uumx._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__07uk530._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_update-role_route_actions_0szyft..js")
R.m(74748)
module.exports=R.m(74748).exports
