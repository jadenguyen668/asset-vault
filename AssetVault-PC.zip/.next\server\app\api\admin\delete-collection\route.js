var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/delete-collection/route.js")
R.c("server/chunks/[root-of-the-server]__09j.jsc._.js")
R.c("server/chunks/_0p.uumx._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_delete-collection_route_actions_0hxs053.js")
R.m(93104)
module.exports=R.m(93104).exports
