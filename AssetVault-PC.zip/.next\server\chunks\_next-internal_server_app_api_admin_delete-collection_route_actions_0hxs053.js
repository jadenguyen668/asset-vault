module.exports=[82283,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_delete-collection_route_actions_0hxs053.js.map