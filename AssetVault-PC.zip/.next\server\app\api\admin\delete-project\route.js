var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/delete-project/route.js")
R.c("server/chunks/[root-of-the-server]__104.--o._.js")
R.c("server/chunks/_0p.uumx._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_delete-project_route_actions_0-tv2cm.js")
R.m(82487)
module.exports=R.m(82487).exports
