var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/storage/download/route.js")
R.c("server/chunks/[root-of-the-server]__0ppwi.k._.js")
R.c("server/chunks/_0p.uumx._.js")
R.c("server/chunks/[root-of-the-server]__07uk530._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/_next-internal_server_app_api_storage_download_route_actions_0w623hs.js")
R.m(78947)
module.exports=R.m(78947).exports
