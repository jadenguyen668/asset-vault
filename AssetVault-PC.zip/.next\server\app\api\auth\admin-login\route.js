var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/admin-login/route.js")
R.c("server/chunks/[root-of-the-server]__0rpya1z._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_admin-login_route_actions_0~.kk1j.js")
R.m(71842)
module.exports=R.m(71842).exports
