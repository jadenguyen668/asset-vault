var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/convert-spine/route.js")
R.c("server/chunks/[root-of-the-server]__118j-pz._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/[root-of-the-server]__00go6su._.js")
R.c("server/chunks/_next-internal_server_app_api_convert-spine_route_actions_04a.yh7.js")
R.m(11040)
module.exports=R.m(11040).exports
