module.exports=[66356,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_admin_delete-project_route_actions_0-tv2cm.js.map