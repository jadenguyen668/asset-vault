globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/zSlkwlOPhC4oNRm8E6Vlw/_buildManifest.js",
    "static/zSlkwlOPhC4oNRm8E6Vlw/_ssgManifest.js",
    "static/zSlkwlOPhC4oNRm8E6Vlw/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/15xrurgzs99gv.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/0~xv7x6hk6uwp.js",
    "static/chunks/0waegh9wwqt5d.js",
    "static/chunks/turbopack-0pqlw77sdafeq.js"
  ]
};
