var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/storage/upload/route.js")
R.c("server/chunks/[root-of-the-server]__06aloxi._.js")
R.c("server/chunks/_0p.uumx._.js")
R.c("server/chunks/[root-of-the-server]__07uk530._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/_next-internal_server_app_api_storage_upload_route_actions_0tqxumi.js")
R.m(84248)
module.exports=R.m(84248).exports
